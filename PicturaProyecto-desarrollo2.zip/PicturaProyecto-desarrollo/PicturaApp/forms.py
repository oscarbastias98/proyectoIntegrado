from django import forms
from django.contrib.auth.models import User
from PicturaApp.models import Usuario
from django.core import validators
import re

def validate_password_requirements(value):
    if len(value) < 8:
        raise forms.ValidationError("La contraseña debe tener al menos 8 caracteres.", code='min_length')
        
    if not re.search(r"^(?=.*[A-Z])(?=.*[^a-zA-Z0-9\s])", value):
        raise forms.ValidationError(
            "La contraseña debe contener al menos una mayúscula y un carácter especial.",
            code='security_requirements'
        )

class UsuarioRegistroForm(forms.ModelForm): # Cambiamos a ModelForm
        CUSTOM_WIDGET_ATTRS = {'class': 'form-control Input-Underline'}

        # Mapear tus campos a los campos del User de Django
        nombre_usuario = forms.CharField(
        label='Nombre de Usuario',
        widget=forms.TextInput(attrs={**CUSTOM_WIDGET_ATTRS, 'placeholder': 'Nombre de Usuario' , 'id': 'NombreUsuario'}),
        validators=[validators.MinLengthValidator(2), validators.MaxLengthValidator(50)]
        )
        nombre_completo = forms.CharField(
        label='Nombre Completo',
        widget=forms.TextInput(attrs={**CUSTOM_WIDGET_ATTRS, 'placeholder': 'Nombre Completo' , 'id': 'NombreCompleto'}),
        validators=[validators.MinLengthValidator(2), validators.MaxLengthValidator(100)]
        )
        correo = forms.EmailField(
        label='Correo',
        widget=forms.EmailInput(attrs={**CUSTOM_WIDGET_ATTRS, 'placeholder': 'Correo', 'id': 'Correo'}),
        validators=[validators.MinLengthValidator(5), validators.MaxLengthValidator(50)]
        )
        contraseña = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={**CUSTOM_WIDGET_ATTRS, 'placeholder': 'Contraseña' , 'id': 'ContraseñaUsuario'}),
        validators=[validate_password_requirements]
        )
        confirmar_contraseña = forms.CharField(
        label='Confirmar Contraseña',
        widget=forms.PasswordInput(attrs={**CUSTOM_WIDGET_ATTRS, 'placeholder': 'Confirmar Contraseña' , 'id': 'ContraseñaConfirmUsuario'}),
        required=True
        )

        class Meta:
            model = User # ¡Cambiamos el modelo a User!
            fields = ['nombre_usuario', 'nombre_completo', 'correo', 'contraseña'] # Quitamos cuenta_bancaria

        def clean(self):
        # ... (tu método clean se mantiene igual, valida las contraseñas) ...
            cleaned_data = super().clean()
            contraseña = cleaned_data.get("contraseña")
            confirmar_contraseña = cleaned_data.get("confirmar_contraseña")

            if contraseña and confirmar_contraseña and contraseña != confirmar_contraseña:
                    raise forms.ValidationError(
                        "Las contraseñas no coinciden. Por favor, revísalas.",
                        code='password_mismatch'
                    )
            return cleaned_data

        def clean_nombre_usuario(self):
            # Verificación de que el usuario no exista
            username = self.cleaned_data.get('nombre_usuario')
            if User.objects.filter(username=username).exists():
                raise forms.ValidationError("Este nombre de usuario ya está en uso.")
            return username

class UsuarioLoginForm(forms.Form): 
    CUSTOM_WIDGET_ATTRS = {'class': 'form-control Input-Underline'}

    nombre_usuario = forms.CharField(
        widget=forms.TextInput(attrs={**CUSTOM_WIDGET_ATTRS, 'placeholder': 'Nombre de Usuario', 'id': 'NombreUsuario'}),
        max_length=50
    )
    
    contraseña = forms.CharField(
        widget=forms.PasswordInput(attrs={**CUSTOM_WIDGET_ATTRS, 'placeholder': 'Contraseña', 'id' : 'ContraseñaUsuario'})
    )

class CreadorRegistroForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields ='__all__'

    #Asignar validadores a datos del modelo
    id_usuario = forms.IntegerField()
    fecha = forms.IntegerField()


    #Widgets
    id_usuario.widget.attrs['class'] = 'form-control'
    fecha.widget.attrs['class'] = 'form-control'

class AdminRegistroForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields ='__all__'

    #Asignar validadores a datos del modelo
    nombre_completo = forms.CharField(validators=[ #Nombre
        validators.MinLengthValidator(2),
        validators.MaxLengthValidator(15)
    ])
    nombre_usuario = forms.CharField(validators=[ #Nombre
        validators.MinLengthValidator(2),
        validators.MaxLengthValidator(15)
    ])
    correo = forms.CharField(validators=[ #Correo
        validators.MinLengthValidator(5),
        validators.MaxLengthValidator(30)
    ])
    contraseña= forms.CharField(validators=[ #Correo
        validators.MinLengthValidator(5),
        validators.MaxLengthValidator(30)
    ])
    id_usuario = forms.IntegerField()


    #Widgets
    nombre_completo.widget.attrs['class'] = 'form-control'
    nombre_usuario.widget.attrs['class'] = 'form-control'
    correo.widget.attrs['class'] = 'form-control'
    contraseña.widget.attrs['class'] = 'form-control'
    id_usuario.widget.attrs['class'] = 'form-control'