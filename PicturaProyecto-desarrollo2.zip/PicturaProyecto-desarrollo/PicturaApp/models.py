from django.db import models

class Usuario(models.Model):
    nombre_completo = models.CharField(max_length=100)
    nombre_usuario = models.CharField(max_length=50)
    correo = models.CharField(max_length=50)
    contraseña = models.CharField(max_length=128)
    cuenta_bancaria_id = models.IntegerField(null=True, blank=True)

class Creador(models.Model):
    id_usuario = models.IntegerField()
    fecha = models.DateField(auto_now_add=True)

class Administrador(models.Model):
    nombre_completo = models.CharField(max_length=100)
    nombre_usuario = models.CharField(max_length=50)
    correo = models.CharField(max_length=50)
    contraseña = models.CharField(max_length=50)
    id_usuario = models.IntegerField()


class Publicacion(models.Model):
    nombre = models.CharField(max_length=100)
    fecha = models.DateField(auto_now_add=True)
    hora = models.TimeField(auto_now_add=True)
    etiquetas = models.CharField(max_length=50)
    tipo = models.CharField(max_length=50)
    creador_id = models.IntegerField()
    archivo = models.ImageField(upload_to="home", null=True, blank=True)
    def __str__(self):
        if self.archivo:
            return self.archivo.name
        return "Publicacion sin imagen"


class Interaccion(models.Model):
    comentario = models.CharField(max_length=100)
    fecha = models.DateField(auto_now_add=True)
    hora = models.TimeField(auto_now_add=True)
    calificacion = models.IntegerField()
    usuario_id = models.IntegerField()
    publicacion_id = models.IntegerField()


class Denuncia(models.Model):
    descripcion = models.CharField(max_length=100)
    fecha = models.DateField(auto_now_add=True)
    hora = models.TimeField(auto_now_add=True)
    verificacion = models.BooleanField(default=False)
    usuario_id = models.IntegerField()
    publicacion_id = models.IntegerField()
