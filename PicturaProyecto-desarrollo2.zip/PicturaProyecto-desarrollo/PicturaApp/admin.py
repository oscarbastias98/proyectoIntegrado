from django.contrib import admin
from PicturaApp.models import Usuario, Creador, Administrador
#Admin Usuario
class Admin_Usuario(admin.ModelAdmin):
    list_display=['id','nombre_completo','nombre_usuario','correo','contraseña','cuenta_bancaria_id']

#Admin Creador
class Admin_Creador(admin.ModelAdmin):
    list_display=['id','id_usuario','fecha']

#Admin Admin
class Admin_Admin(admin.ModelAdmin):
    list_display=['id','nombre_completo','nombre_usuario','correo','contraseña','id_usuario']

#Registrar los modelos
admin.site.register(Usuario, Admin_Usuario)
admin.site.register(Creador, Admin_Creador)
admin.site.register(Administrador, Admin_Admin)