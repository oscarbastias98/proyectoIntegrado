from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth.hashers import check_password, make_password
from PicturaApp.models import Usuario
from PicturaApp.forms import UsuarioRegistroForm, UsuarioLoginForm 
from django.contrib import messages
#.....
from django.http import JsonResponse
from .models import Publicacion


# views.py

from django.shortcuts import render, redirect # redirect es más limpio
from django.urls import reverse
from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth import login, authenticate, logout 
from django.contrib.auth.models import User # Importar el User de Django
from PicturaApp.forms import UsuarioRegistroForm, UsuarioLoginForm 
from django.contrib import messages

def crearUsuario(request):
    form = UsuarioRegistroForm() 
    if request.method == 'POST':
        form = UsuarioRegistroForm(request.POST)
        if form.is_valid():
            # Extraer datos limpios
            username = form.cleaned_data['nombre_usuario']
            password = form.cleaned_data['contraseña']
            email = form.cleaned_data['correo']
            first_name = form.cleaned_data['nombre_completo']

            # Usar el método de Django para crear usuarios (maneja el hash de la contraseña)
            user = User.objects.create_user(username=username, password=password, email=email, first_name=first_name)
            user.save()
            
            messages.success(request, '¡Te has registrado correctamente! Ahora inicia sesión.')
            return redirect('login') # Usar redirect
        else:
            pass 

    data = {'form': form}
    return render(request, 'PicturaApp/Register.html', data)


# views.py (Asegúrate de tener estas importaciones)
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.contrib.auth.hashers import check_password # ¡Necesaria para la lógica antigua!
from PicturaApp.models import Usuario # ¡Necesaria para la lógica antigua!
from PicturaApp.forms import UsuarioLoginForm
from django.contrib import messages

def validarUsuario(request): 
    if request.method == 'POST':
        form = UsuarioLoginForm(request.POST) 
    
        if form.is_valid():
            username = form.cleaned_data['nombre_usuario']
            password = form.cleaned_data['contraseña']
            
            # 1. INTENTO DE LOGIN ESTÁNDAR (Django User)
            user = authenticate(request, username=username, password=password)
            
            if user is not None:
                login(request, user)
                return redirect('home')
            
            else:
                # 2. INTENTO DE LOGIN/MIGRACIÓN DESDE LA BASE DE DATOS ANTIGUA
                try:
                    # Buscar en la tabla antigua (Usuario)
                    usuario_antiguo = Usuario.objects.get(nombre_usuario=username)
                    
                    # 3. Validar la contraseña con el hash antiguo
                    if check_password(password, usuario_antiguo.contraseña):
                        
                        # **MIGRACIÓN AUTOMÁTICA AL SISTEMA NUEVO**
                        
                        # Crear el usuario en la tabla de Django (auth_user)
                        user_nuevo = User.objects.create_user(
                            username=usuario_antiguo.nombre_usuario,
                            email=usuario_antiguo.correo,
                            password=password, # Pasar el texto plano para que Django lo hashee
                            first_name=usuario_antiguo.nombre_completo 
                        )
                        user_nuevo.save()
                        
                        # Ahora que está migrado, iniciar sesión
                        login(request, user_nuevo)
                        
                        # Opcional: Eliminar el usuario de la tabla antigua para no confundir
                        usuario_antiguo.delete()
                        
                        messages.success(request, f'¡Sesión iniciada! Tu cuenta ha sido migrada automáticamente. Bienvenido, {username}.')
                        return redirect('home')

                    else:
                        # Contraseña incorrecta en el modelo antiguo
                        messages.error(request, 'Credenciales inválidas. Contraseña incorrecta.')
                        return redirect('login')

                except Usuario.DoesNotExist:
                    # El usuario no existe ni en el modelo nuevo ni en el modelo antiguo
                    messages.error(request, 'Credenciales inválidas. El usuario no existe.')
                    return redirect('login') 
                    
        else:
            messages.error(request, 'Por favor, completa ambos campos correctamente.')
            return redirect('login')
    else:
        form = UsuarioLoginForm()
        
    context = {'form': form}
    return render(request, 'PicturaApp/Login.html', context)

def cambiarContraseña(request): 
    if request.method == 'POST':
        form = UsuarioLoginForm(request.POST) 
        
        if form.is_valid():
            username = form.cleaned_data['nombre_usuario']
            password = form.cleaned_data['contraseña']
            
            user = authenticate(request, username=username, password=password)
            
            if user is not None:                
                messages.info(request, f'Credenciales verificadas. Aquí iría la lógica para cambiar la contraseña.')
                return redirect('home')
            else:
                # Las credenciales fallaron en la tabla User de Django
                messages.error(request, 'Credenciales inválidas. Usuario o contraseña incorrecta.')
                return redirect('login') 
        else:
            messages.error(request, 'Por favor, completa ambos campos correctamente.')
            return redirect('login') 
    else:
        form = UsuarioLoginForm()
        
    context = {'form': form}
    # Asumiendo que quieres mostrar el formulario de login/verificación si el método es GET
    return render(request, 'PicturaApp/Login.html', context)

def home(request):
    # Filtra solo publicaciones de ARTE con imagen
    publicaciones = Publicacion.objects.all()

    return render(request, "PicturaApp/Home.html", {
        "publicaciones": publicaciones
    })
def cerrarSesion(request):
    logout(request)
    messages.info(request, "Tu sesión se ha cerrado de forma segura.")
    return render(request, 'PicturaApp/Logout.html', {})


def feed_random(request):
    # Obtener 20 publicaciones aleatorias
    publicaciones = Publicacion.objects.order_by("?")[:20]

    resultado = []
    for pub in publicaciones:
        resultado.append({
            "id": pub.id,
            "nombre": pub.nombre,
            "fecha": str(pub.fecha),
            "hora": str(pub.hora),
            "tipo": pub.tipo,
            "etiquetas": pub.etiquetas,
            "creador_id": pub.creador_id,
            "imagen_url": pub.archivo.url if pub.archivo else None,
        })

    return JsonResponse({"publicaciones": resultado})




